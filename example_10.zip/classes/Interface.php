<?php

interface OrderInterface {

	function save($con);
	function validate();
	function notify();

}
 