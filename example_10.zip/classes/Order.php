<?php

class Order implements OrderInterface{

	public $name;
	public $email;
	public $phone;
	public $date;

	public function __construct($name, $email, $phone){

		$this->name = $name;
		$this->email = $email;
		$this->phone = $phone;

		$this->date = date("Y-m-d H:i:s");
	}

    public function validate(){
	    if( !empty($this->name) and !empty($this->email)){
		    return true;
	    } else {
		    return false;
	    }
    }

	public function save($con){

		$sql =  "INSERT INTO `orders` SET `name`='". mysqli_real_escape_string($con, $this->name)
				."', `email`='".mysqli_real_escape_string($con, $this->email)
				."', `phone`='".mysqli_real_escape_string($con, $this->phone)
				."', `date`='".mysqli_real_escape_string($con, $this->date) ."'";

		$result = mysqli_query($con, $sql);

		return $result;
	}

	public function notify(){

		mail('ddavidov@mindk.com', 'New order', sprintf('...'));
	}

}
 