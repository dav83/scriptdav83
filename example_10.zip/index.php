<?php

require_once('classes/Interface.php');
require_once('classes/Order.php');

$connection = mysqli_connect('localhost', 'root', 'masterJedi', 'myproject');

if(true || !empty($_GET['send'])){

	$name = empty($_GET['name']) ? '' : $_GET['name'];

	$order = new Order($name, @$_GET['email'], @$_GET['phone']);

	if($order instanceof OrderInterface)
	{
		if($order->validate()){
			$order->save($connection);
			$order->notify();
		} else {
			echo "Invalid data!";
		}
	}else{
		echo "Message";
	}
}